To open with arduino ide -> weatherstation.ino
To open with Visual Studio (for those who have the plug in) -> WeatherStation.vcxproj