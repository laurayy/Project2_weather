Thanks for downloading the app!

-> To start the app run WeatherStats.exe

->The app will not start if don't have a 
  properties.txt file in the folder. 

->The properties.txt will look like this;

COM4
9600
NewYork
USA
dajasbhdasg231231a

-> The first line is the serial port where your arduino is connected
->The second line is the baudrate
-> The third line is yor city 
-> The fourth line is the code of your country
-> The fith line is the API KEY of the openweathermap site in order for you
   to fetch the weather info

YOU HAVE TO CREATE AN ACCOUNT IN https://openweathermap.org/appid

in order to get an API key for your code.

-> After you have an api key just paste it into the fifth line of the properties file :)

-> The program will not work if you don't have an arduino or something connected
   to the serial port.

Happy DIY!!!
